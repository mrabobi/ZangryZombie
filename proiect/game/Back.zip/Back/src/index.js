/*We import the external classes*/
import Knight from "./Knigth.js";
import InputHandler from "./input.js";
import Background from "./Backgroud.js";
import Zombie from "./Zombie.js";
/* We get the canvas and the context*/
let canvas = document.getElementById("gameScreen");
let ctx = canvas.getContext("2d");
/*We declare the window's width and height as constants*/
const gamewidth = 1600;
const gameheight = 900;
let b1 = new Background();
let k1 = new Knight(gamewidth, gameheight,b1);
let i1 = new InputHandler(k1);
let z1 = new Zombie(gamewidth, gameheight);

var oldTimeStamp;

function sleep(delay) {
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
}
function gameLoop(timeStamp) {

    //Calculate the number of seconds passed
    //since the last frame
   if(k1.pause===false)
{
    var secondsPassed = (timeStamp - oldTimeStamp) / 1000;
    oldTimeStamp = timeStamp;

    //Calculate fps
    var fps = Math.round(1 / secondsPassed);

    //Draw number to the screen

    // Perform the drawing operation
    ctx.clearRect(0, 0, 1000, 900);
  	b1.draw(ctx);
  	i1.execute_commands();
  	k1.update_position();
  	k1.draw(ctx);
  	z1.draw(ctx);
    ctx.font = '25px Arial';
    ctx.fillStyle = 'blue';
    ctx.fillText("Frame: " + k1.frame, 0, 50);
    ctx.fillText("Jumping: " + k1.pause, 0, 100);
  
}
requestAnimationFrame(gameLoop);

    // The loop function has reached it's end
    // Keep requesting new frames
}
//setTimeout(gameLoop,2000000);
gameLoop(10);
