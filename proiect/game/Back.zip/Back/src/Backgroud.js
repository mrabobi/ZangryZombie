/*A class used to draw the background*/
export default class Backgroud {
  constructor() {
    this.image = document.getElementById("BackGround");
   	this.columns=16;
   	this.rows=9;
    this.tiles = [document.getElementById("Tile1"),document.getElementById("Tile2"),document.getElementById("Tile3")];
    this.layout=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
              0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
    this.new_layout(this.rows-1);
  }
  /*For now,the draw method draws a single picture using multiple images imported from the
HTML document*/
  draw(ctx) {

    ctx.drawImage(this.image, 0, 0, this.columns*100, this.rows*100);
  	for(let index=0;index<this.layout.length;index++)
  	{
  		if(this.layout[index]!=0)

  		{
 		let value=this.layout[index]-1;
  		let start_y=Math.floor(index/this.columns)*100;
  		let start_x=index%this.columns*100;
  		ctx.drawImage(this.tiles[value], start_x, start_y, 100, 100);
		}

  	}
  }

  get_tile_at(position_x,position_y)
  {

      var row=  Math.floor(position_y/100);
      var column= Math.floor(position_x/100); 
    return this.layout[row*this.columns+column];
  }

  get_height()
  {
    var i=0;
    while(this.layout[i*this.columns+this.columns-1]==0)
      i++;
    return i;
  }

  new_layout(height)
  {
    
    for(var i=0;i<this.rows;i++)
      for(var j=0;j<this.columns;j++)
        this.layout[i*this.columns+j]=0;
      this.layout[height*this.columns]=1;
      this.layout[height*this.columns+1]=2;
      for(var i=height;i<this.rows;i++)
        {
          this.layout[i*this.columns]=2;
          this.layout[i*this.columns+1]=2;
        }
        var column=2;
        var last_height=height;
       
        while(column<this.columns)
        {
          if(last_height<this.rows-1 && last_height>1)
          {
          var height_change=Math.floor(Math.random()*3);
          if(height_change==1 && last_height!=this.rows-1)
          {
            last_height+=1;
          }

          if(height_change==2)
          {
            last_height-=1;
          }

          this.layout[height*this.columns+column]=2;
          this.layout[height*this.columns+column+1]=2;
      for(var i=last_height;i<this.rows;i++)
        {
          this. layout[i*this.columns+column]=2;
          this.layout[i*this.columns+column+1]=2;
        }
        }
        else if(last_height==1)
          {
            var height_change=Math.floor(Math.random()*2);
          if(height_change==1)
          {
            last_height+=1;
          }

          this.layout[height*this.columns+column]=2;
          this.layout[height*this.columns+column+1]=2;
      for(var i=last_height;i<this.rows;i++)
        {
          this. layout[i*this.columns+column]=2;
          this.layout[i*this.columns+column+1]=2;
        }

          }

          else if(last_height==this.rows-1)
          {
            var height_change=Math.floor(Math.random()*2);
          if(height_change==1)
          {
            last_height-=1;
          }

          this.layout[height*this.columns+column]=2;
          this.layout[height*this.columns+column+1]=2;
      for(var i=last_height;i<this.rows;i++)
        {
          this. layout[i*this.columns+column]=2;
          this.layout[i*this.columns+column+1]=2;
        }

          }
        column+=2;


        }

  }



}
